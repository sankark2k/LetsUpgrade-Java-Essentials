import java.io.*;
import java.util.*;

class Odd{
	public static void main(String args[]){
		Scanner sc = new Scanner(System.in);
		int arr[]=new int[5];
		int i;
		System.out.println("Enter 5 values : ");

		for(i=0; i<=4; i++){
			arr[i]=sc.nextInt();
		}
		for(i=0; i<=4; i++){
			if(arr[i]%2 !=0){
				System.out.println("Odd num is "+ arr[i]);
			}
			else{
				continue;
			}
		}
	}
}