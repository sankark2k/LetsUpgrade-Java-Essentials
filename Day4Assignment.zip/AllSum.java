import java.io.*;
import java.util.*;

class AllSum{
	public static void main(String args[]){
		Scanner sc = new Scanner(System.in);

		int arr[] = new int[5];
		int i, sum=0; 

		System.out.println("Enter 5 inputs ");

		for(i=0; i<5; i++){
			arr[i] = sc.nextInt();
			sum +=arr[i];

		}

		System.out.println("Sum of 5 inputs is "+ sum);
	}
}